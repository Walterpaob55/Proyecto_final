import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

// Esta clase representa el objeto moneda
public class Moneda
{
    // Las características de la moneda
    private String codigo,nombre,pais;
    private double Taza_cambio;
// Metodo constructor
    public Moneda()
    {
        this.codigo=codigo;
        this.nombre=nombre;
        this.pais=pais;
        this.Taza_cambio=Taza_cambio;
    }
    // Metodo para ingresar datos de la moneda
    public void ingresarDatos()
    {
        nombre =JOptionPane.showInputDialog("Ingrese el nombre de la moneda");
        codigo= JOptionPane.showInputDialog("Ingrese el código de la moneda");
        pais= JOptionPane.showInputDialog("Ingrese el nombre del pais de origen de la moneda");
        Taza_cambio=Double.parseDouble(JOptionPane.showInputDialog("Ingrese la taza de cambio a dolares de la moneda"));
        JOptionPane.showMessageDialog(null,"La moneda que ingresaste tiene como\n Codigo: "+codigo+" \n Nombre: "+nombre+" \n Pais: "+pais+"  \n taza de cambio a dolares: "+Taza_cambio +" USD");
    }
    // Permite extrar el nombre
    public String getNombre()
    {
        return nombre;
    }
    // Permite extraer la taza de cambio
    public double getTaza_cambio()
    {
        return Taza_cambio;
    }
    // Permite extraer el codigo de la moneda
    public String getCodigo()
    {
        return codigo;
    }
    // Permite extraer el pais de origen
    public String getPais()
    {
        return pais;
    }
    // Permite asignar una nueva taza de cambio en funcion de la taza ingresada
    public void setTaza_cambio(double taza_cambio)
    {
        this.Taza_cambio=taza_cambio;
    }
}
