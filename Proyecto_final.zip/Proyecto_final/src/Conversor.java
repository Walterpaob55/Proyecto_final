public class Conversor
{
    // Atributos
    double cantidadMoneda, cantidadConvertida;
    // Constructor
    public Conversor()
    {
        this.cantidadMoneda=cantidadMoneda;
        this.cantidadConvertida=cantidadConvertida;
    }

}
