import javax.swing.*;
import java.util.ArrayList;

public class Lista_Moneda extends Moneda
{
    // Lista de monedas del sistema
    ArrayList<Moneda> ListaMonedas = new ArrayList<>();
    // Método para imprimir los datos de la monedas registradas con sus datos
    public void MostrarMonedas()
    {
        for(Moneda i:ListaMonedas)
        {
            System.out.println("Nombre: "+i.getNombre());
            System.out.println("Codigo: "+i.getCodigo());
            System.out.println("Pais: "+i.getPais());
            System.out.println("Taza de cambio a USD: "+i.getTaza_cambio());
        }
    }
    // Metodo para ingresar la moneda a la lista
    public void IngresarMoneda(Moneda Mone)
    {
        ListaMonedas.add(Mone);
    }


// Permite cambiar la taza de cambio de la moneda en función del nombre y la taza nueva
    public void cambiarTaza(String nombre,double Taza)
    {
        for(Moneda i:ListaMonedas)
        {
            if(nombre.equals(i.getNombre()))
            {
                i.setTaza_cambio(Taza);
            }
        }
    }
// Permite buscar la taza de cambio de la moneda de nombre ingresado
    public double buscarTaza(String nombre)
    {
        double taz=0;
        for(Moneda i:ListaMonedas)
        {
            if(nombre.equals(i.getNombre()))
            {
                taz=i.getTaza_cambio();
            }
        }
        return taz;
    }
    // Permite buscar una moneda en funcion de su nombre
    public boolean EMoneda(String nombre)
    {
        for(Moneda i:ListaMonedas)
        {
            if(nombre.equals(i.getNombre()))
            {
                i.getNombre();
                return true;
            }
        }
        return false;
    }
    // Permite eliminar una moneda
    public void eliminarMoneda(String nombre)
    {
        for(Moneda i:ListaMonedas)
        {
            if(nombre.equals(i.getNombre()))
            {
                ListaMonedas.remove(i);
                break;
            }
        }
    }

}
