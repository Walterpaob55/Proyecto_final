import javax.swing.*;
import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        // Variables principales
        int opcion;
        boolean existe,existe2,existe3,existe4;
        // Instanciar nueva lista de monedas
        Lista_Moneda lista = new Lista_Moneda();
        // Permite la lectura de datos
        Scanner lr= new Scanner(System.in);
        // Menu principal
        do{
            System.out.println("Bienvenido al conversor de divisas");
            System.out.println("1. Ingresar moneda");
            System.out.println("2. Ver monedas registradas");
            System.out.println("3. Convertir moneda");
            System.out.println("4. Modificar taza de cambio de una moneda");
            System.out.println("5. Eliminar una moneda");
            System.out.println("6. Salir");
            System.out.print("Ingrese una opcion: ");
            opcion = lr.nextInt();
            // Casos del menu principal
            switch(opcion)
            {
                case 1:
                    // Instanciar moneda
                    Moneda mon = new Moneda();
                    // Ingresar datos de moneda e ingresarlas a la lista
                    mon.ingresarDatos();
                    existe4= lista.EMoneda(mon.getNombre());
                    if(existe4==true)
                    {
                        JOptionPane.showMessageDialog(null,"La moneda de ese nombre existe");
                    } else
                    {
                        lista.IngresarMoneda(mon);
                    }
                    break;
                case 2:
                    // Mostrar en pantalla todas las monedas registradas
                    lista.MostrarMonedas();
                    break;
                case 3:
                    // Poner el nombre de una moneda
                    String local=JOptionPane.showInputDialog("Ingrese el nombre de la moneda que tiene");
                    // Existe moneda
                    existe=lista.EMoneda(local);
                    if(existe==false)
                    {
                        JOptionPane.showMessageDialog(null,"No existe esa moneda en el sistema");
                    } else
                    {
                        Conversor conversor = new Conversor();
                        conversor.cantidadMoneda=Double.parseDouble(JOptionPane.showInputDialog(null,"Ingrese la cantidad de moneda que quiere convertir"));
                        conversor.cantidadConvertida=conversor.cantidadMoneda* lista.buscarTaza(local);
                        System.out.println("La conversion equivale a "+conversor.cantidadConvertida+" USD");
                    }
                    break;
                case 4:
                    String local2=JOptionPane.showInputDialog(null,"Ingrese el nombre de la moneda para cambiar la taza de cambio");
                    existe2= lista.EMoneda(local2);
                    if(existe2==false)
                    {
                        JOptionPane.showMessageDialog(null,"No existe esa moneda en el sistema");
                    } else
                    {
                        double nueva_taz=Double.parseDouble(JOptionPane.showInputDialog("Ingrese la nueva taza de cambio"));
                        lista.cambiarTaza(local2,nueva_taz);
                        JOptionPane.showMessageDialog(null,"Taza de cambio modificada correctamente");
                    }
                    break;
                case 5:
                    String local3=JOptionPane.showInputDialog(null,"Ingrese el nombre de la moneda para eliminarla del sistema");
                    existe3= lista.EMoneda(local3);
                    if(existe3==false)
                    {
                        JOptionPane.showMessageDialog(null,"No existe esa moneda en el sistema");
                    } else
                    {
                        lista.eliminarMoneda(local3);
                        System.out.println("Moneda eliminada correctamente");
                    }
                    break;
                case 6:
                    System.out.println("Saliendo del programa");
                    break;
                default:
                    System.out.println("Opcion no mencionada");
                    break;
            }
        }
        while(opcion != 6);
    }
}